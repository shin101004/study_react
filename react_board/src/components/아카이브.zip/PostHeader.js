import React,{useState} from 'react';
import styled from "styled-components";
import Clock from "react-live-clock";

const PostHeaderBlock = styled.div`
padding : 10px 15px 20px 15px;
border-bottom : 2px solid #afafaf;
h1 {
color : #aaa;
letter-spacing : 10px;
margin : 0;
}

.day {
   color : #a6a6a6;
}
`;

function PostHeader() {
    return (
        <PostHeaderBlock>
            <h1>게시판</h1>
            <Clock format={'HH:mm:ss'} ticking={true}/>
        </PostHeaderBlock>
    )
}

export default PostHeader;