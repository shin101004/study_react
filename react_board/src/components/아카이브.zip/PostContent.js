import React from 'react';

function PostContent({id}) {
    
    return (
        <div>

        </div>
    )
}

export default PostContent;